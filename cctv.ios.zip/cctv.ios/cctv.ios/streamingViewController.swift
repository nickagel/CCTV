//
//  streamingViewController.swift
//  cctv.ios
//
//  Created by Student on 11/3/16.
//  Copyright © 2016 Student. All rights reserved.
//

import UIKit

class streamingViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
